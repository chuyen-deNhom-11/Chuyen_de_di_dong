package com.example.foodonline.utils;

import java.util.Random;

public class Constant {
    public static final String SHARE_NAME = "SHARE_NAME";
    public static final String USER_REFERENCES = "Users";
    public static final String USER_ID ="userID";
    public static final String COMBO_ID ="IdCombo";
    public static final String COMBO = "Combo";
}
