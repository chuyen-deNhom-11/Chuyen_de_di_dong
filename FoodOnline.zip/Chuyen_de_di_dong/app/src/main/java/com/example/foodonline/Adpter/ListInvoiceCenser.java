package com.example.foodonline.Adpter;

public class ListInvoiceCenser {
}
